Github地址
	https://github.com/senzuo/CPL/tree/master/exer1part1
运行环境
	操作系统：Ubuntu 16.04
	编译工具：gcc (Ubuntu 5.4.0-6ubuntu1~16.04.10) 5.4.0

